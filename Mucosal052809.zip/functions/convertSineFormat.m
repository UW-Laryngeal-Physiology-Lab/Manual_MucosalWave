% --------------------------------------------------------------------
function [amplitude,phase] = convertSineFormat(a, b)
%Converts sine waves from rectangular to polar format
%Uses trig identity amplitude*sin(wt+phase) = A*cos(wt)+B*sin(wt)
%Author: Ben Schoepke
%Last modified: 4/14/09

%Inputs: 
%   a = A (cosine coefficient)
%   b = B (sine coefficient)
%Outputs:
%   amplitude = amplitude (as described above)
%   phase = phase, ranging from 0 to 2pi (as described above) 

amplitude = sqrt(a.^2 + b.^2);
if a ~= 0
    phase = atan(b ./ a);
elseif a == 0 & b > 0
    phase = pi / 2;
elseif a == 0 & b < 0
    phase = -pi / 2;
else
    phase = 0;
end

% atan ranges from -pi/2 to pi/2, so needs to be adjusted for values to be
% accurate depending on the quadrant
if a < 0 & b > 0
    phase = pi + phase;
elseif a < 0 & b < 0
    phase = pi + phase;
elseif a > 0 & b < 0
    phase = 2*pi + phase;
end