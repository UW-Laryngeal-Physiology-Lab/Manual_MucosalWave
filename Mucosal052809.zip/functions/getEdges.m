function [y,x] = ...
    getEdges(mwaveimage, bwimage, usethreshold, vocalFold, order, ncycles)
% This function allows the user to manually extract the vocal fold edges
% from a thresholded (binary) mucosal wave image.
% Adapted to function form by Ben Schoepke
% Last modified: 5/19/09

close(setdiff(allchild(0),gcf)); % close all open figures
if strcmp(vocalFold,'ru'), vocalFoldName = 'right upper';
elseif strcmp(vocalFold,'rl'), vocalFoldName = 'right lower';
elseif strcmp(vocalFold,'lu'), vocalFoldName = 'left upper';
elseif strcmp(vocalFold,'ll'), vocalFoldName = 'left lower'; end

y = 0;
x = 0;

if nargin < 5, return; end

% Initialize output image
imageSize = size(bwimage);
edgeImage = zeros(imageSize(1), imageSize(2));
displayImage = bwimage * 255;

figure

if usethreshold
    
    colormap(hot)
    imagesc(displayImage)
    currAxis = gca;
    axis off
    set(gcf, 'Name', 'Select vocal fold edges');

    numEdges = order * ncycles;
    instructions = sprintf('Select all edges within each cycle of the %s vocal fold, for a total of %d edges.',vocalFoldName,numEdges);

    % The user extracts each required edge, one-by-one with the getrect fcn.
    for i = 1:numEdges
        temp = zeros(imageSize);
        validRect = [false false]; % sentinel values for while loop
        while (~validRect(1) || ~validRect(2))
            validRect = [false false];
            try
                figure(1)
                title(currAxis, instructions);
                rect = getrect(figure(1)); %user chooses a rectangular region in curr figure
            catch
                return % if no rectangle selected
            end
            xselect = floor(rect(1));
            yselect = floor(rect(2));
            width = floor(rect(3));
            height = floor(rect(4));

            if (width == 0 || height == 0)
                errordlg('Invalid rectangle (cannot be a single point). Try again.')
                uiwait; % wait until user closes error dialog
            else
                validRect(1) = true;
            end

            % Constrain rectangle to dimensions of current image
            if xselect <= 0
                width = width + xselect;
                xselect = 1;
            end
            if yselect <= 0
                height = height + yselect;
                yselect = 1; 
            end
            if xselect + width > imageSize(2)
                width = imageSize(2) - xselect;
            end
            if yselect + height > imageSize(1)
                height = imageSize(1) - yselect;
            end

            %temp is part of bwimage selected
            temp(yselect:yselect+height,xselect:xselect+width) = bwimage(yselect:yselect+height,xselect:xselect+width); 
            [row, col] = find(temp ~= 0);

            if ~any(row) && validRect(1)
                errordlg('Invalid rectangle (must include at least one white point). Try again.')
                uiwait; % wait until user closes error dialog
            else
                if validRect(1), validRect(2) = true; end
            end

            %This takes the edges out of the selected region.  The method used to
            %extract the edges depends on whether or not the vocal folds collide in
            %the detected bwimage.
            if validRect(2)
                rowmi = min(row);
                rowma = max(row);
                colmi = min(col);
                colma = max(col);

                if (strcmp(vocalFold, 'ru') || strcmp(vocalFold, 'll'))
                    colma = col(row == rowmi);
                    colmi = col(row == rowma);
                elseif (strcmp(vocalFold, 'lu') || strcmp(vocalFold, 'rl'))
                    colma = col(row == rowma);
                    colmi = col(row == rowmi);
                end

                edgeImage(rowmi:rowma(1),colmi:colma(1)) = ...
                    bwimage(rowmi:rowma(1),colmi:colma(1));

                % Change color of pixels in selected edge and display
                displayImage = updateImage(displayImage,rowmi,rowma(1),colmi,colma(1));
                imagesc(displayImage)


                axis off
            end
        end
    end
    [y,x] = find(edgeImage);
%     hold on
%     colormap('gray');
%     imshow(mwaveimage);
%     plot(x,y,'r.')
%     hold off
%     title(currAxis, 'Red dots are selected edges');
%     pause(0.5) % Wait a half second before closing figure
%     close(gcf)
else
    imagesc(mwaveimage)
    currAxis = gca;
    hold on
    title(currAxis, 'Hit "backspace" to delete last point(s). Hit "Enter" when finished selecting all points.')
    axis off
    set(gcf, 'Name', 'Select points on vocal fold edges');
    colormap('gray')
    try
        [x,y] = getpts;  % user interactively choose points on image
        plot(x,y,'r.')
    catch
        return
        % do nothing (usual expection occurs if figure window is closed)
    end
    hold off

%     try
%         title(currAxis, 'Red dots are selected points');
%     catch
%     % Do nothing, error will occur if selection window closed
%     end
%     pause(1);
    
end % end of if
close(gcf);
pause(0.5);
% hold on
% colormap('gray');
% imshow(mwaveimage);
% plot(x,y,'r.')
% hold off
% title(currAxis, 'Red dots are selected edges');
    
end % end of function

% This function changes the color of the pixels of the selected edge
% Author: Ben Schoepke
% Last Modified: 4/15/09
function updatedImage = updateImage(displayImage,rowmi,rowma,colmi,colma)
    COLOR_VALUE = 96;
    updatedImage = displayImage;
    for r = rowmi:rowma
        for c = colmi:colma
            if updatedImage(r,c) ~= 0, updatedImage(r,c) = COLOR_VALUE; end
        end
    end
end