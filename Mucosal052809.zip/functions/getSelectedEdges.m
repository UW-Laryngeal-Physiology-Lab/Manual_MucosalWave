function edges = getSelectedEdges(handles)

edges = {handles.ruEdges handles.rlEdges handles.luEdges handles.llEdges};