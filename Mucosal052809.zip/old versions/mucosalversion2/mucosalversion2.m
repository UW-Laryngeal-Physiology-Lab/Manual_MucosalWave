%%Written by: Henry Tsui
% Revised by: Erik Bieging
% Revised by: Yue Gao
% Revised by: Lizhu Qi
% This program is uses a curve fitting algorithm to fit a sinusoidal
% function to mucosalversion2 wave data extracted from a kymographic image.
% It performs well for order 1 and order 2, not yet order 3.

function varargout = mucosalversion2(varargin)
% MUCOSALVERSION2 M-file for mucosalversion2.fig
%      MUCOSALVERSION2, by itself, creates a new MUCOSALVERSION2 or raises the existing
%      singleton*.
%
%      H = MUCOSALVERSION2 returns the handle to a new MUCOSALVERSION2 or the handle to
%      the existing singleton*.
%
%      MUCOSALVERSION2('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MUCOSALVERSION2.M with the given input arguments.
%
%      MUCOSALVERSION2('Property','Value',...) creates a new MUCOSALVERSION2 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before mucosalversion2_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to mucosalversion2_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help mucosalversion2

% Last Modified by GUIDE v2.5 02-Jan-2009 12:13:53

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @mucosalversion2_OpeningFcn, ...
                   'gui_OutputFcn',  @mucosalversion2_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin & isstr(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before mucosalversion2 is made visible.
function mucosalversion2_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to mucosalversion2 (see VARARGIN)

% Choose default command line output for mucosalversion2
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes mucosalversion2 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = mucosalversion2_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in load.
function load_Callback(hObject, eventdata, handles)
% hObject    handle to load (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles.no = 400;

no = handles.no;

%This opens an .avi file and loads a specified number of frames.
[name, path] = uigetfile('.avi', 'File Name');

orig = cd;
cd(path);
info = aviinfo(name);
num = info.NumFrames;
set(handles.text1, 'String', name);
vid = aviread(name, 1:no);
cd(orig);
% set(handles.index_text, 'String', 0);
% set(handles.period_text, 'String', 0);
temp = frame2im(vid(1));

%Displays the first frame of the video
imshow(temp, []);

%Initializes the handles
handles.period = 5;
handles.index = 1;
handles.cycle_left = 0;
handles.cycle_right = 0;
handles.rotdeg = 0;
handles.num = num;
handles.pic1 = temp;
handles.vid = vid;
handles.newvid=vid;
handles.name = name;
guidata(hObject, handles);



% --- Executes on button press in cut.
function cut_Callback(hObject, eventdata, handles)
% hObject    handle to cut (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% This function can be used to cut the frames to a smaller area.  It is
% really only necessary for the vertical cropping of the images.
no = handles.no;
vid = handles.vid;
num = handles.num;
temp = handles.pic1;
rotdeg = handles.rotdeg;
rect = getrect(handles.axes1);
a = floor(rect(1));
b = floor(rect(2));
c = floor(rect(3));
d = floor(rect(4));

if(rotdeg == 0)
for i = 1:no
    temp1 = (frame2im(vid(i)));

    newvid{i} = temp1(b:b+d,a:a+c);

end
else
for i = 1:no
    temp1 = (frame2im(vid(i)));
    temp4 = imrotate(temp1, rotdeg, 'loose');
    newvid{i} = temp4(b:b+d,a:a+c);

end
end
temp2 = temp(b:b+d,a:a+c);
imshow(temp2, []);

handles.pic1 = temp2;
handles.newvid = newvid;
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function picnum_CreateFcn(hObject, eventdata, handles)
% hObject    handle to picnum (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background, change
%       'usewhitebg' to 0 to use default.  See ISPC and COMPUTER.
usewhitebg = 1;
if usewhitebg
    set(hObject,'BackgroundColor',[.9 .9 .9]);
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes on slider movement.
function picnum_Callback(hObject, eventdata, handles)
% hObject    handle to picnum (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

%This function allows the user to look through the images before cutting
%the images.
picnum = floor(get(hObject, 'Value'));
% set(handles.text3, 'String', picnum);
handles.picnum = picnum;
guidata(hObject, handles);

%The apply function redisplays the image after the frame has been changed.
apply_Callback(hObject, eventdata, handles);

% --- Executes on button press in apply.
function apply_Callback(hObject, eventdata, handles)
% hObject    handle to apply (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%This function displays an image.
vid = handles.vid;

picnum = handles.picnum;

temp = frame2im(vid(picnum));


% temp1 = imrotate(temp, 90);
imshow(temp, []);

handles.pic1 = temp;

guidata(hObject, handles);



% --- Executes during object creation, after setting all properties.
function line_CreateFcn(hObject, eventdata, handles)
% hObject    handle to line (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background, change
%       'usewhitebg' to 0 to use default.  See ISPC and COMPUTER.
usewhitebg = 1;
if usewhitebg
    set(hObject,'BackgroundColor',[.9 .9 .9]);
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes on slider movement.
function line_Callback(hObject, eventdata, handles)
% hObject    handle to line (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

%This function allows the user to select the pixel column that will be used
%to create the kymographic image.
pic1 = handles.pic1;
s = size(pic1);

set(hObject, 'Max', s(2));
ind = floor(get(hObject, 'Value'));
imshow(pic1, []);
line ([ind ind], [0 s(1)]);

handles.ind = ind;
guidata(hObject, handles);


% --- Executes on button press in wave.
function wave_Callback(hObject, eventdata, handles)
% hObject    handle to wave (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%This function generates the kymographic image.
newvid = handles.newvid;
no = handles.no;

%ind is the column from which the kymopgraphic image is created.
ind= handles.ind;
V = [];

%This loop creats the kymographic image by taking one column of pixels
%from each frame in the image series and putting them in a series.
for i = 1:no
    temp = newvid{i};
    V = [V temp(:, ind)];
end

imshow(V, []);
s = size(V);
handles.s2 = s(2);
handles.m1_wave = V;
guidata(hObject, handles);


function thresh_Callback(hObject, eventdata, handles)
% hObject    handle to thresh (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%This function is called by the slider functions of each of the two
%threshold selection sliders.  It applys a threshold to the kymographic
%image, and displays the thresholded image.

thresh = handles.thresh;

%m_wave is the kymographic image
m_wave = handles.m_wave;

tr = find (m_wave<thresh);

%newpic will be a binary image created by thresholding
newpic = zeros(size(m_wave));

%Sets the values below the threshhold to be white
newpic(tr) = 1;
m_wave(tr) = 255;
imshow(m_wave, []);
handles.newpic = newpic;
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function treshsilder_left_CreateFcn(hObject, eventdata, handles)
% hObject    handle to treshsilder_left (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background, change
%       'usewhitebg' to 0 to use default.  See ISPC and COMPUTER.
usewhitebg = 1;
if usewhitebg
    set(hObject,'BackgroundColor',[.9 .9 .9]);
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes on slider movement.
function treshsilder_left_Callback(hObject, eventdata, handles)
% hObject    handle to treshsilder_left (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

% This function allows the user to change the threshold for the upper vocal
% fold (not the left vocal fold).  
thresh_left = get(hObject, 'Value');
set(handles.text4, 'String', thresh_left);

handles.thresh = thresh_left;
guidata(hObject, handles);
thresh_Callback(hObject, eventdata, handles);


% --- Executes on button press in edge.
function edge_Callback(hObject, eventdata, handles)
% hObject    handle to edge (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% This function uses canny edge detection on the binary image to isolate
% the glottal edges in the kymgraphic image.
newpic = handles.newpic;
m_wave = handles.m_wave;

%bw is a binary edge map
% % bw = edge(newpic,'canny',0.9);
bw = edge(newpic,'canny',[]);
tr = find(bw==1);

%m_wave1 is a copy of m_wave with the detected edges displayed on top of
%the image
m_wave1 = m_wave;
m_wave1(tr) = 255;
figure(1);
imshow(m_wave1,[]);
handles.bw = bw;

guidata(hObject, handles);


% --- Executes on button press in lu.
function lu_Callback(hObject, eventdata, handles)
% hObject    handle to lu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% This function performs the sinusoidal curve fitting process on the left
% upper vocal fold.  The following three functions are exactly the same,
% but perform the analysis on the other vocal fold segments.  This function
% is the only one with comments, but the others are exactly the same.
bw = handles.bw;
newbwlu = zeros(size(bw));
display('bw');
s = size(newbwlu);
m_wave = handles.m_wave;
period = handles.period;
index = handles.index; %order
clu=zeros(1,3);

% This loop allows the user to select the portions of the detected vocal
% fold edge should be used in for the curve fitting.  For each cycle, the
% user selects a rectangle containing the desired data points.
for i = 1:period
    temp = zeros(size(bw));
    %user selects a rectangle
    rect = getrect(figure(1));
    a =abs( floor(rect(1)));
    b =abs( floor(rect(2)));
    c = abs(floor(rect(3)));
    d =abs( floor(rect(4)));
    %temp is the portion of the image selected
    temp(b:b+d,a:a+c) = bw(b:b+d,a:a+c);
    [row, col] = find(temp == 1);
    %This takes the edges out of the selected region.  The method used to
    %extract the edges depends on whether or not the vocal folds collide in
    %the detected image.
    if (get(handles.overlap, 'Value') == 1)
        rowma = max(row);
        rowmi = min(row);
        colma = col(find(row == rowmi));
        colmi = col(find(row == rowma));
        %newbwlu is a binary image containing only the edge pixels that
        %were selected by the user
        newbwlu(rowmi:rowma,colmi(1):colma(1)) = bw(rowmi:rowma,colmi(1):colma(1));
    else
        rowmi = min(row);
        colmi = min(col);
        colma = col(find(row == rowmi));
        rowma = row(find(col == colmi));
        newbwlu(rowmi:rowma(1),colmi:colma(1)) = bw(rowmi:rowma(1),colmi:colma(1));
    end
    % newbwlu is displayed after each cycle is selected in figure 3.
    figure(3);
    imshow(newbwlu,[]);

end
handles.newbwlu = newbwlu;
guidata(hObject, handles);
%peakslider(handles);
%me =32;
%lux and luy are vectors containing the x and y coordinates of each edge
%point in newbwlu
[luy,lux] = find(newbwlu == 1);
y=luy;
%This is used to calculate the period of the data. t is the period
if(index==2)
    me=handles.me;
else
% %     me = floor(mean(ruy(:)));
    me = floor(mean(luy(:)));
end
tr = lux(find(luy==me));
t = (sum(tr) - period*tr(1))*2/(1+period-1)/(period-1);
if(index==2)
t = (sum(tr) - period/2*tr(1))*2/(1+period/2-1)/(period/2-1);
end;
n = [];
V = [];
var = 2*pi*lux/t;     %%%%% var Ϊ w

% This creates an array containing a sine and cosine corresponding to each
% order using the calculated period and the x-values specified in lux.
for i = 1:index
    xx{2*i-1} = sin(i*var);  %%[sinw cosw sin2w cos2w sin3w cos3w]
    xx{2*i} = cos(i*var);
end

% This performs the actual curve fitting by calculating the optimal
% amplitude for each sinusoidal function in the array xx.
for j = 1:2*index
    ly(j) = sum(y.*xx{j}) - mean(y)*sum(xx{j});
    n = [n ly(j)];
    m = [];
    for k = 1:2*index
        l(j,k) = sum(xx{k}.*xx{j}) - mean(xx{k})*sum(xx{j});
        m= [m l(j,k)];
    end
    V = [V m'];
end

a = V'\n';  % % (n'/V')

%a0 is the DC offset of the sinusoid
a0 = mean(y);

for ii = 1:2*index
    a0 = a0 - a(ii)*mean(xx{ii});
end

% This calculates the amplitude (clu) and phase (philu) of the sinusoid.
for kk = 1:index
    clu(kk) = sqrt(a(2*kk-1)^2 + a(2*kk)^2);
    philu(kk) = atan(a(2*kk-1)/a(2*kk));
    eval(['set(handles.text' num2str(49+kk) ' ,''String'', clu(' num2str(kk) '));']);
    eval(['set(handles.text' num2str(46+kk) ' ,''String'', philu(' num2str(kk) '));']);
end

%Display the results
set(handles.text9, 'String', t);
set(handles.text10, 'String', a0);

% xxx and yyy are created based on the calculated sinusoid function and are
% used to plot the results.
xxx= 1:s(2);
yyy = a0;
for jj = 1:index
    yyy = yyy +  a(2*jj-1)*sin(2*jj*pi*xxx/t) + a(2*jj) * cos(2*jj*pi*xxx/t);
end

%Plot the results
imshow(m_wave);
hold on;
plot(xxx,yyy);

% % show phi and c
% % set(handles.text50, 'String', clu(1));
% % set(handles.text47, 'String', philu(1));
% % set(handles.text51, 'String', clu(2));
% % set(handles.text48, 'String', philu(2));
% % set(handles.text52, 'String', clu(3));
% % set(handles.text49, 'String', philu(3));




%Save the results
handles.luxi = lux;
handles.luyi = luy;
handles.clu = clu;
handles.philu = philu;
handles.lux = xxx;
handles.luy = yyy;
handles.lua = a;
handles.lua0 = a0;
handles.newbwlu = newbwlu;
guidata(hObject, handles);

% --- Executes on button press in ll.
function ll_Callback(hObject, eventdata, handles)
% hObject    handle to ll (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
lux = handles.lux;
luy = handles.luy;
cll=zeros(1,3);
bw = handles.bw;
newbwll = zeros(size(bw));
s = size(newbwll);
m_wave = handles.m_wave;
period = handles.period;

for i = 1:period
    temp = zeros(size(bw));
    rect = getrect(figure(1));
    a = floor(rect(1));
    b = floor(rect(2));
    c = floor(rect(3));
    d = floor(rect(4));
    temp(b:b+d,a:a+c) = bw(b:b+d,a:a+c);
    [row, col] = find(temp == 1);
    if (get(handles.overlap, 'Value') == 1) 
        rowma = max(row);
        rowmi = min(row);
        colma = col(find(row == rowma));
        colmi = col(find(row == rowmi));
        newbwll(rowmi:rowma,colmi(1):colma(1)) = bw(rowmi:rowma,colmi(1):colma(1));
    else 
        rowma = max(row);
        colmi = min(col);
        colma = col(find(row == rowma));
        rowmi = row(find(col == colmi));
        newbwll(rowmi:rowma(1),colmi:colma(1)) = bw(rowmi:rowma(1),colmi:colma(1));
    end
    figure(3);
    imshow(newbwll,[]);
    
end

[lly,llx] = find(newbwll == 1);
index = handles.index;

if(index==2)
    me=handles.me;
else
   me = floor(mean(lly(:)));
end
tr = llx(find(lly==me));

t = (sum(tr) - period*tr(1))*2/(1+period-1)/(period-1);
if(index==2)
t = (sum(tr) - period/2*tr(1))*2/(1+period/2-1)/(period/2-1);
end;
y = lly;
n = [];
V = [];
var = 2*pi*llx/t;


for i = 1:index
    
    xx{2*i-1} = sin(i*var); xx{2*i} = cos(i*var);
end

for j = 1:2*index
    ly(j) = sum(y.*xx{j}) - mean(y)*sum(xx{j});
    n = [n ly(j)];
    m = [];
    for k = 1:2*index
        l(j,k) = sum(xx{k}.*xx{j}) - mean(xx{k})*sum(xx{j});
        m= [m l(j,k)];
    end
    V = [V m'];
end

a = V'\n';

a0 = mean(y);

for ii = 1:2*index
    a0 = a0 - a(ii)*mean(xx{ii});
end

for kk = 1:index
    cll(kk) = sqrt(a(2*kk-1)^2 + a(2*kk)^2);
    phill(kk) = atan(a(2*kk-1)/a(2*kk));
    eval(['set(handles.text' num2str(55+kk) ' ,''String'', cll(' num2str(kk) '));']);
    eval(['set(handles.text' num2str(52+kk) ' ,''String'', phill(' num2str(kk) '));']);
end

set(handles.text25, 'String', t);
set(handles.text26, 'String', a0);
% % set(handles.text56, 'String', cll(1));
% % set(handles.text53, 'String', phill(1));
% % set(handles.text57, 'String', cll(2));
% % set(handles.text54, 'String', phill(2));
% % set(handles.text58, 'String', cll(3));
% % set(handles.text55, 'String', phill(3));

xxx= 1:s(2);
yyy = a0;
for jj = 1:index
    yyy = yyy +  a(2*jj-1)*sin(2*jj*pi*xxx/t) + a(2*jj) * cos(2*jj*pi*xxx/t);
end


imshow(m_wave);
hold on;
plot(lux,luy, 'b');
hold on;
plot(xxx,yyy, 'r');
handles.llxi = llx;
handles.llyi = lly;
handles.cll = cll;
handles.phill = phill;
handles.llx = xxx;
handles.lly = yyy;
handles.lla0 = a0;
handles.lla = a;
handles.newbwll = newbwll;
guidata(hObject, handles);

% --- Executes on button press in ru.
function ru_Callback(hObject, eventdata, handles)
% hObject    handle to ru (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
lux = handles.lux;
luy = handles.luy;
llx = handles.llx;
lly = handles.lly;

bw = handles.bw;
cru=zeros(1,3);
newbwru = zeros(size(bw));
s = size(newbwru);
m_wave = handles.m_wave;
period = handles.period;

for i = 1:period
temp = zeros(size(bw));
rect = getrect(figure(1));
a = floor(rect(1));
b = floor(rect(2));
c = floor(rect(3));
d = floor(rect(4));
temp(b:b+d,a:a+c) = bw(b:b+d,a:a+c);
[row, col] = find(temp == 1);
if (get(handles.overlap, 'Value') == 1) 
rowma = max(row);
rowmi = min(row);
colma = col(find(row == rowma));
colmi = col(find(row == rowmi));
newbwru(rowmi:rowma,colmi(end):colma(end)) = bw(rowmi:rowma,colmi(end):colma(end));
else 
    rowmi = min(row);
    colma = max(col);
    colmi = col(find(row == rowmi));
    rowma = row(find(col == colma));
   newbwru(rowmi:rowma(end),colmi(end):colma) = bw(rowmi:rowma(end),colmi(end):colma);
end
figure(3);
imshow(newbwru,[]);

end

[ruy,rux] = find(newbwru == 1);
index = handles.index;


if(index==2)
    me=handles.me;
else
   me = floor(mean(ruy(:)));
end
tr = rux(find(ruy==me));

t = (sum(tr) - period*tr(1))*2/(1+period-1)/(period-1);
if(index==2)
t = (sum(tr) - period/2*tr(1))*2/(1+period/2-1)/(period/2-1);
end;
y = ruy;
n = [];
V = [];
var = 2*pi*rux/t;

index = handles.index;

for i = 1:index
    
xx{2*i-1} = sin(i*var); xx{2*i} = cos(i*var);
end

for j = 1:2*index
    ly(j) = sum(y.*xx{j}) - mean(y)*sum(xx{j});
    n = [n ly(j)];
    m = [];
    for k = 1:2*index
        l(j,k) = sum(xx{k}.*xx{j}) - mean(xx{k})*sum(xx{j});
        m= [m l(j,k)];
    end
    V = [V m'];
end

a = V'\n';

a0 = mean(y);

for ii = 1:2*index
    a0 = a0 - a(ii)*mean(xx{ii});
end

for kk = 1:index
    cru(kk) = sqrt(a(2*kk-1)^2 + a(2*kk)^2);
    phiru(kk) = atan(a(2*kk-1)/a(2*kk));
    eval(['set(handles.text' num2str(61+kk) ' ,''String'', cru(' num2str(kk) '));']);
    eval(['set(handles.text' num2str(58+kk) ' ,''String'', phiru(' num2str(kk) '));']);
end

set(handles.text33, 'String', t);
set(handles.text34, 'String', a0);
% % set(handles.text62, 'String', cru(1));
% % set(handles.text59, 'String', phiru(1));
% % set(handles.text63, 'String', cru(2));
% % set(handles.text60, 'String', phiru(2));
% % set(handles.text64, 'String', cru(3));
% % set(handles.text61, 'String', phiru(3));

xxx= 1:s(2);
yyy = a0;
for jj = 1:index
yyy = yyy +  a(2*jj-1)*sin(2*jj*pi*xxx/t) + a(2*jj) * cos(2*jj*pi*xxx/t);
end

imshow(m_wave);
hold on;
plot(lux,luy, 'b');
hold on;
plot(llx,lly, 'r');
hold on;
plot(xxx, yyy, 'g');
handles.ruxi = rux;
handles.ruyi = ruy;
handles.cru = cru;
handles.phiru = phiru;
handles.rux = xxx;
handles.ruy = yyy;
handles.rua = a;
handles.rua0 = a0;
handles.newbwru = newbwru;
guidata(hObject, handles);

% --- Executes on button press in rl.
function rl_Callback(hObject, eventdata, handles)
% hObject    handle to rl (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% hObject    handle to rl (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
rux = handles.rux;
ruy = handles.ruy;
lux = handles.lux;
luy = handles.luy;
llx = handles.llx;
lly = handles.lly;

bw = handles.bw;
newbwrl = zeros(size(bw));
crl=zeros(1,3);
s = size(newbwrl);
m_wave = handles.m_wave;
period = handles.period;

for i = 1:period
temp = zeros(size(bw));
rect = getrect(figure(1));
a = floor(rect(1));
b = floor(rect(2));
c = floor(rect(3));
d = floor(rect(4));
temp(b:b+d,a:a+c) = bw(b:b+d,a:a+c);
[row, col] = find(temp == 1);
if (get(handles.overlap, 'Value') == 1) 
rowma = max(row);
rowmi = min(row);
colma = col(find(row == rowmi));
colmi = col(find(row == rowma));
newbwrl(rowmi:rowma,colmi(1):colma(1)) = bw(rowmi:rowma,colmi(1):colma(1));
else 
    rowma = max(row);
    colma = max(col);
    colmi = col(find(row == rowma));
    rowmi = row(find(col == colma));
   newbwrl(rowmi(1):rowma,colmi(1):colma) = bw(rowmi(1):rowma,colmi(1):colma);
end
figure(3);
imshow(newbwrl,[]);

end

[rly,rlx] = find(newbwrl == 1);
index = handles.index;

if(index==2)
    me=handles.me;
else
    me = floor(mean(rly(:)));
end
tr = rlx(find(rly==me));

t = (sum(tr) - period*tr(1))*2/(1+period-1)/(period-1);
if(index==2)
t = (sum(tr) - period/2*tr(1))*2/(1+period/2-1)/(period/2-1);
end;
y = rly;
n = [];
V = [];
var = 2*pi*rlx/t;

index = handles.index;

for i = 1:index
    
xx{2*i-1} = sin(i*var); xx{2*i} = cos(i*var);
end

for j = 1:2*index
    ly(j) = sum(y.*xx{j}) - mean(y)*sum(xx{j});
    n = [n ly(j)];
    m = [];
    for k = 1:2*index
        l(j,k) = sum(xx{k}.*xx{j}) - mean(xx{k})*sum(xx{j});
        m= [m l(j,k)];
    end
    V = [V m'];
end

a = V'\n';

a0 = mean(y);

for ii = 1:2*index
    a0 = a0 - a(ii)*mean(xx{ii});
end

for kk = 1:index
    crl(kk) = sqrt(a(2*kk-1)^2 + a(2*kk)^2);
    phirl(kk) = atan(a(2*kk-1)/a(2*kk));
    eval(['set(handles.text' num2str(67+kk) ' ,''String'', crl(' num2str(kk) '));']);
    eval(['set(handles.text' num2str(64+kk) ' ,''String'', phirl(' num2str(kk) '));']);
end

set(handles.text41, 'String', t);
set(handles.text42, 'String', a0);
% % set(handles.text68, 'String', crl(1));
% % set(handles.text65, 'String', phirl(1));
% % set(handles.text69, 'String', crl(2));
% % set(handles.text66, 'String', phirl(2));
% % set(handles.text70, 'String', crl(3));
% % set(handles.text67, 'String', phirl(3));

xxx= 1:s(2);
yyy = a0;
for jj = 1:index
yyy = yyy +  a(2*jj-1)*sin(2*jj*pi*xxx/t) + a(2*jj) * cos(2*jj*pi*xxx/t);
end


imshow(m_wave);
hold on;
plot(lux,luy, 'b');
hold on;
plot(llx,lly, 'r');
hold on;
plot(rux, ruy, 'g');
hold on;
plot(xxx, yyy, 'y');
handles.rlxi = rlx;
handles.rlyi = rly;
handles.crl = crl;
handles.phirl = phirl;
handles.rlx = xxx;
handles.rly = yyy;
handles.rla0 = a0;
handles.rla = a;
handles.newbwrl = newbwrl;
guidata(hObject, handles);

function overlap_Callback(hObject, eventdata, handles)
% hObject    handle to overlap (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of overlap


% --- Executes during object creation, after setting all properties.
function cycle_right_CreateFcn(hObject, eventdata, handles)
% hObject    handle to cycle_right (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background, change
%       'usewhitebg' to 0 to use default.  See ISPC and COMPUTER.
usewhitebg = 1;
if usewhitebg
    set(hObject,'BackgroundColor',[.9 .9 .9]);
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes on slider movement.
function cycle_right_Callback(hObject, eventdata, handles)
% hObject    handle to cycle_right (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

% This function is for cropping the kymographic image from the right.
cycle_right = floor(get(hObject, 'Value'));
handles.cycle_right = cycle_right;
guidata(hObject, handles);
%cycleapply is called to redisplay the image after the sliderbar is moved
%by the user
cycleapply_Callback(hObject, eventdata, handles);


function cycleapply_Callback(hObject, eventdata, handles)
% hObject    handle to cycleapply (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% This function redraws the kymograpic image when the user crops it with
% the slider bars.

cycle_right = handles.cycle_right;
cycle_left = handles.cycle_left;
m1_wave = handles.m1_wave;
s2 = handles.s2;

%temp is the newly defined image
temp = m1_wave(:, 1+cycle_left:s2-cycle_right);

imshow(temp);
handles.m_wave = temp;
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function period_text_CreateFcn(hObject, eventdata, handles)
% hObject    handle to period_text (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function period_text_Callback(hObject, eventdata, handles)
% hObject    handle to period_text (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of period_text as text
%        str2double(get(hObject,'String')) returns contents of period_text as a double

% This function records the number of cycles input by the user.

period = str2num(get(hObject, 'String'));
handles.period = period;
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function index_text_CreateFcn(hObject, eventdata, handles)
% hObject    handle to index_text (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function index_text_Callback(hObject, eventdata, handles)
% hObject    handle to index_text (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of index_text as text
%        str2double(get(hObject,'String')) returns contents of index_text as a double

% This function records the order number input by the user.
index = str2num(get(hObject, 'String'));
handles.index = index;
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function threshslider_right_CreateFcn(hObject, eventdata, handles)
% hObject    handle to threshslider_right (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background, change
%       'usewhitebg' to 0 to use default.  See ISPC and COMPUTER.
usewhitebg = 1;
if usewhitebg
    set(hObject,'BackgroundColor',[.9 .9 .9]);
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes on slider movement.
function threshslider_right_Callback(hObject, eventdata, handles)
% hObject    handle to threshslider_right (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

% This slider is used to select the threshold for the lower (not right)
% vocal fold.

thresh_right = get(hObject, 'Value');
set(handles.text47, 'String', thresh_right);

handles.thresh = thresh_right;
guidata(hObject, handles);
% thresh is called to display the newly thresholded image.
thresh_Callback(hObject, eventdata, handles);


% --- Executes on button press in order1.
function order1_Callback(hObject, eventdata, handles)
% hObject    handle to order1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% This function displays the first order sinusoid parameters calculated in
% previous functions.

clu = handles.clu;
cll = handles.cll;
cru = handles.cru;
crl = handles.crl;
philu = handles.philu;
phill = handles.phill;
phiru = handles.phiru;
phirl = handles.phirl;

set(handles.text50, 'String', clu(1));
set(handles.text56, 'String', cll(1));
set(handles.text62, 'String', cru(1));
set(handles.text68, 'String', crl(1));
set(handles.text47, 'String', philu(1));
set(handles.text53, 'String', phill(1));
set(handles.text59, 'String', phiru(1));
set(handles.text65, 'String', phirl(1));

% --- Executes on button press in order2.
function order2_Callback(hObject, eventdata, handles)
% hObject    handle to order2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% This function displays the second order sinusoid parameters calculated in
% previous functions, if a second or third order sine wave was desired by
% the user.

clu = handles.clu;
cll = handles.cll;
cru = handles.cru;
crl = handles.crl;
philu = handles.philu;
phill = handles.phill;
phiru = handles.phiru;
phirl = handles.phirl;

set(handles.text51, 'String', clu(2));
set(handles.text57, 'String', cll(2));
set(handles.text63, 'String', cru(2));
set(handles.text69, 'String', crl(2));
set(handles.text48, 'String', philu(2));
set(handles.text54, 'String', phill(2));
set(handles.text60, 'String', phiru(2));
set(handles.text66, 'String', phirl(2));

% --- Executes on button press in order3.
function order3_Callback(hObject, eventdata, handles)
% hObject    handle to order3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% This functio displays the third order sinusoid parameters calculated in
% previous functions, if third order sine wave was requested by the user.

clu = handles.clu;
cll = handles.cll;
cru = handles.cru;
crl = handles.crl;
philu = handles.philu;
phill = handles.phill;
phiru = handles.phiru;
phirl = handles.phirl;

set(handles.text52, 'String', clu(3));
set(handles.text58, 'String', cll(3));
set(handles.text64, 'String', cru(3));
set(handles.text70, 'String', crl(3));
set(handles.text49, 'String', philu(3));
set(handles.text55, 'String', phill(3));
set(handles.text61, 'String', phiru(3));
set(handles.text67, 'String', phirl(3));


% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double

% This function chnges the number of frames that are read when the video is
% loaded.

no = str2num(get(hObject, 'String'));
handles.no = no;
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function cycle_left_CreateFcn(hObject, eventdata, handles)
% hObject    handle to cycle_left (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background, change
%       'usewhitebg' to 0 to use default.  See ISPC and COMPUTER.
usewhitebg = 1;
if usewhitebg
    set(hObject,'BackgroundColor',[.9 .9 .9]);
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes on slider movement.
function cycle_left_Callback(hObject, eventdata, handles)
% hObject    handle to cycle_left (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

% This slider allows the user to crop the kymographic image from the left.

cycle_left = floor(get(hObject, 'Value'));
handles.cycle_left = cycle_left;
guidata(hObject, handles);
%cycleapply is called to redisplay the newly cropped image
cycleapply_Callback(hObject, eventdata, handles);


% --- Executes on button press in save.
function save_Callback(hObject, eventdata, handles)
% hObject    handle to save (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% This function saves the results of the analysis to .dat files.

index = handles.index;
name = handles.name;

%Loads the data
clu = handles.clu;
cll = handles.cll;
cru = handles.cru;
crl = handles.crl;

philu = handles.philu;
phill = handles.phill;
phiru = handles.phiru;
phirl = handles.phirl;

lua0 = handles.lua0;
lua = handles.lua;
lla = handles.lla;
lla0 = handles.lla0;
rua0 = handles.rua0;
rua = handles.rua;
rla = handles.rla;
rla0 = handles.rla0;

%Oragnizes the data
Vlu = [lua0 0 0 0];
Vll = [lla0 0 0 0];
Vru = [rua0 0 0 0];
Vrl = [rla0 0 0 0];

for i = 1:index
    templu = [lua(2*i-1) lua(2*i) clu(i) philu(i)];
    templl = [lla(2*i-1) lla(2*i) cll(i) phill(i)];
    tempru = [rua(2*i-1) rua(2*i) cru(i) phiru(i)];
    temprl = [rla(2*i-1) rla(2*i) crl(i) phirl(i)];
    
    Vlu = [Vlu; templu];
    Vll = [Vll; templl];
    Vru = [Vru; tempru];
    Vrl = [Vrl; temprl];
end

l = length(name);
% Takes the name of the video file and removes the ".avi" suffix.
file = name(1:l-4);
% Saves a file for each vocal fold segment.
save ([file, '_upper_right.dat'], 'Vlu', '-ascii');
save ([file, '_upper_left.dat'], 'Vll', '-ascii');
save ([file, '_lower_right.dat'], 'Vru', '-ascii');
save ([file, '_lower_left.dat'], 'Vrl', '-ascii');


% --- Executes during object creation, after setting all properties.
function rotate_CreateFcn(hObject, eventdata, handles)
% hObject    handle to rotate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background, change
%       'usewhitebg' to 0 to use default.  See ISPC and COMPUTER.
usewhitebg = 1;
if usewhitebg
    set(hObject,'BackgroundColor',[.9 .9 .9]);
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes on slider movement.
function rotate_Callback(hObject, eventdata, handles)
% hObject    handle to rotate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

% This function allows the user to rotate the images before the kymographic
% image is created, so that the glottis is oriented horizontally in the
% image frame.

rotdeg = get(hObject, 'Value');
handles.rotdeg = rotdeg;
guidata(hObject, handles);
rotapply_Callback(hObject, eventdata, handles)


function rotapply_Callback(hObject, eventdata, handles)
% hObject    handle to rotapply (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% This function is called to redisplay the image after the user has rotated
% it.

vid = handles.vid;
picnum = handles.picnum;
pic1 = frame2im(vid(picnum));

rotdeg = handles.rotdeg;
%rotates the image
rotimg = imrotate(pic1, rotdeg, 'loose');
%displays the rotated image
imshow(rotimg, []);
handles.pic1 = rotimg;
guidata(hObject, handles);


% --- Executes on button press in createws.
function createws_Callback(hObject, eventdata, handles)
% hObject    handle to createws (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% This function can be used to export the results into an Excel
% spreadsheet.  It creates a new Excel file where the first sheet has the
% results of the analysis.  (first order only)

%Asks the user to enter the spreadsheet name.
[name, path] = uiputfile({'*.xls'}, 'Save Excel File As...');

%Creates the column titles for the spreadsheet
rows1_2 = {'','','','','','Right Upper', '','','','Right Lower','','','',...
    'Left Upper','','','','Left Lower','','';...
    'Larynx', 'Pressure', 'Elongation', 'Cycles','',...
    'Period (RU)','Amplitude (RU)','Phase (RU)','','Period (RL)',...
    'Amplitude (RL)','Phase (RL)','','Period (LU)','Amplitude (LU)','Phase (LU)','',...
    'Period (LL)','Amplitude (LL)','Phase (LL)'};

%Creates a row containing the results
row3 = {str2double(get(handles.larynx, 'String')),...
    str2double(get(handles.pressure, 'String')),...
    str2double(get(handles.elongation, 'String')),...
    str2double(get(handles.period_text, 'String')),'',...
    str2double(get(handles.text9, 'String')),...
    str2double(get(handles.text50, 'String')),...
    str2double(get(handles.text47, 'String')),'',...
    str2double(get(handles.text33, 'String')),...
    str2double(get(handles.text62, 'String')),...
    str2double(get(handles.text59, 'String')),'',...
    str2double(get(handles.text25, 'String')),...
    str2double(get(handles.text56, 'String')),...
    str2double(get(handles.text53, 'String')),'',...
    str2double(get(handles.text41, 'String')),...
    str2double(get(handles.text68, 'String')),...
    str2double(get(handles.text65, 'String'))};

%Puts the column titles and data into a single matrix array.
mat = vertcat(rows1_2, row3);

orig = cd;
cd(path);
%Writes the Excel file
xlswrite(name, mat);
cd(orig);






% --- Executes on button press in append.
function append_Callback(hObject, eventdata, handles)
% hObject    handle to append (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% This function appends the results to a specified Excel file, most likely
% a file created using the createws function.  It adds a row of data with
% the current results.

%Asks the user for the Excel file to append the data to.
[name, path] = uiputfile({'*.xls'}, 'Append to fisrt seet of...');

orig = cd;
cd(path);
%Reads the current file and determines how many rows it is, so that the
%data can be appended to the first vacant row of the sheet.
current = xlsread(name);
sz = size(current);
rows = sz(1);

%Creates the new row of data.
newrow = {str2double(get(handles.larynx, 'String')),...
    str2double(get(handles.pressure, 'String')),...
    str2double(get(handles.elongation, 'String')),...
    str2double(get(handles.period_text, 'String')),'',...
    str2double(get(handles.text9, 'String')),...
    str2double(get(handles.text50, 'String')),...
    str2double(get(handles.text47, 'String')),'',...
    str2double(get(handles.text33, 'String')),...
    str2double(get(handles.text62, 'String')),...
    str2double(get(handles.text59, 'String')),'',...
    str2double(get(handles.text25, 'String')),...
    str2double(get(handles.text56, 'String')),...
    str2double(get(handles.text53, 'String')),'',...
    str2double(get(handles.text41, 'String')),...
    str2double(get(handles.text68, 'String')),...
    str2double(get(handles.text65, 'String'))};

% Writes the data to the specified row
xlswrite(name, newrow, 1, ['A', num2str(rows + 3)]);

cd(orig);



function larynx_Callback(hObject, eventdata, handles)
% hObject    handle to larynx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of larynx as text
%        str2double(get(hObject,'String')) returns contents of larynx as a double


% --- Executes during object creation, after setting all properties.
function larynx_CreateFcn(hObject, eventdata, handles)
% hObject    handle to larynx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function elongation_Callback(hObject, eventdata, handles)
% hObject    handle to elongation (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of elongation as text
%        str2double(get(hObject,'String')) returns contents of elongation as a double


% --- Executes during object creation, after setting all properties.
function elongation_CreateFcn(hObject, eventdata, handles)
% hObject    handle to elongation (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function pressure_Callback(hObject, eventdata, handles)
% hObject    handle to pressure (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of pressure as text
%        str2double(get(hObject,'String')) returns contents of pressure as a double


% --- Executes during object creation, after setting all properties.
function pressure_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pressure (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end




% --- Executes on button press in saveedgedata.
function saveedgedata_Callback(hObject, eventdata, handles)
% hObject    handle to saveedgedata (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% This function is used to save the x and y coordinates of the data points
% of the extrcted edges.  It saves four files, one for each vocal fold lip.
% The first column is x and the second column is y.

% Loads the x and y data vectors for each lip.
luxi = handles.luxi;
luyi = handles.luyi;
llxi = handles.llxi;
llyi = handles.llyi;
ruxi = handles.ruxi;
ruyi = handles.ruyi;
rlxi = handles.rlxi;
rlyi = handles.rlyi;

% Creates 2 column matricies containing the x and y coordinates of each
% point.
lumat = [luxi luyi];
llmat = [llxi llyi];
rumat = [ruxi ruyi];
rlmat = [rlxi rlyi];

% Prompts the user for a filename and location.
[name, path] = uiputfile({'*.txt'});

orig = cd;
cd(path);

%Saves the 4 matricies with the specified filename.  The last 4 characters
%of name are removed to remove the ".txt" extension, which is replaced
%after the appended lip name.
save([name(1:end-4), '_left_upper_edge.txt'], 'lumat', '-ascii', '-tabs');
save([name(1:end-4), '_left_lower_edge.txt'], 'rumat', '-ascii', '-tabs');
save([name(1:end-4), '_right_upper_edge.txt'], 'llmat', '-ascii', '-tabs');
save([name(1:end-4), '_right_lower_edge.txt'], 'rlmat', '-ascii', '-tabs');

cd(orig);






% --- Executes on button press in savedatapts.
function savedatapts_Callback(hObject, eventdata, handles)
% hObject    handle to savedatapts (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% This function saves the points used to plot the sinusoids.  It creates 4
% separate text files, one for each sinusoid.  The first column contains
% the x values and the second column contains y values.

%Loads the data
lux = handles.lux;
luy = handles.luy;
llx = handles.llx;
lly = handles.lly;
rux = handles.rux;
ruy = handles.ruy;
rlx = handles.rlx;
rly = handles.rly;

% Creates 2 column matricies containing the x and y coordinates of each
% point.
lumat = [lux luy];
llmat = [llx lly];
rumat = [rux ruy];
rlmat = [rlx rly];

[name, path] = uiputfile({'*.txt'});

orig = cd;
cd(path);

%Saves the 4 matricies with the specified filename.  The last 4 characters
%of name are removed to remove the ".txt" extension, which is replaced
%after the appended lip name.
save([name(1:end-4), '_left_upper_sinewave.txt'], 'lumat', '-ascii', '-tabs');
save([name(1:end-4), '_left_lower_sinewave.txt'], 'rumat', '-ascii', '-tabs');
save([name(1:end-4), '_right_upper_sinewave.txt'], 'llmat', '-ascii', '-tabs');
save([name(1:end-4), '_right_lower_sinewave.txt'], 'rlmat', '-ascii', '-tabs');

cd(orig);




% --- Executes on slider movement.
function peakslidder_Callback(hObject, eventdata, handles)
% hObject    handle to peakslidder (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

newpic = handles.newpic;
s = size(newpic);
set(hObject, 'Max', s(1));
ind = floor(get(hObject, 'Value'));
imshow(newpic, []);
line ([0,s(2)],[ind,ind]);
handles.me=ind;
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function peakslidder_CreateFcn(hObject, eventdata, handles)
% hObject    handle to peakslidder (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end




% --- Executes on slider movement.
function lowpeakslidder_Callback(hObject, eventdata, handles)
% hObject    handle to lowpeakslidder (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

newpic = handles.newpic;
s = size(newpic);
set(hObject, 'Max', s(1));
ind = floor(get(hObject, 'Value'));
imshow(newpic, []);
line ([0,s(2)],[ind,ind]);
handles.me=ind;
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function lowpeakslidder_CreateFcn(hObject, eventdata, handles)
% hObject    handle to lowpeakslidder (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end




% --- Executes on button press in Cut.
function Cut_Callback(hObject, eventdata, handles)
% hObject    handle to Cut (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)




% --- Executes during object creation, after setting all properties.
function text47_CreateFcn(hObject, eventdata, handles)
% hObject    handle to text47 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


